"""Turn a high-dimensional embedding cube into a 3-band RGB preview.

Two methods, both pure NumPy and unit-testable:

* ``pca`` — fit a 3-component PCA on a subsample of the valid pixels (SVD on the
  mean-centred sample), project every valid pixel onto those components, then
  stretch each of the three channels to 8-bit by a percentile clip.
* ``bands`` — pick three embedding bands directly and percentile-stretch each.

Invalid pixels (nodata / non-finite) are written as black ``(0, 0, 0)``.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import numpy as np
from numpy.typing import NDArray

from ._num import as_float
from .descriptor import DEFAULT_NODATA
from .ml import valid_mask_from_nodata

METHODS: tuple[str, ...] = ("pca", "bands")


def stretch_values(
    values: NDArray[Any], *, low_pct: float = 2.0, high_pct: float = 98.0
) -> NDArray[Any]:
    """Percentile-clip a 1-D array and scale it to ``uint8`` ``[0, 255]``.

    A constant (or near-constant) channel maps to all zeros rather than dividing
    by zero.
    """
    arr = as_float(values).reshape(-1)
    if arr.size == 0:
        return np.zeros(0, dtype=np.uint8)
    lo = float(np.percentile(arr, low_pct))
    hi = float(np.percentile(arr, high_pct))
    if hi <= lo:
        return np.zeros(arr.shape, dtype=np.uint8)
    scaled = np.clip((arr - lo) / (hi - lo), 0.0, 1.0)
    out: NDArray[Any] = np.round(scaled * 255.0).astype(np.uint8)
    return out


def fit_pca(
    matrix: NDArray[Any],
    n_components: int = 3,
    *,
    seed: int = 0,
    max_samples: int = 100_000,
) -> tuple[NDArray[Any], NDArray[Any]]:
    """Fit a PCA on an ``(n_samples, n_bands)`` matrix.

    Returns ``(mean, components)`` where ``components`` is ``(k, n_bands)`` with
    ``k = min(n_components, n_bands)``. Project new data as
    ``(x - mean) @ components.T``. A deterministic subsample bounds the SVD cost.
    """
    arr = as_float(matrix)
    if arr.ndim != 2:
        raise ValueError(f"expected a 2-D (n_samples, n_bands) matrix, got {arr.shape}")
    n_samples = arr.shape[0]
    if n_samples == 0:
        raise ValueError("need at least one sample for PCA")
    if n_samples > max_samples:
        rng = np.random.default_rng(seed)
        index = rng.choice(n_samples, size=max_samples, replace=False)
        sample = arr[index]
    else:
        sample = arr
    mean = sample.mean(axis=0)
    centered = sample - mean
    _, _, vt = np.linalg.svd(centered, full_matrices=False)
    k = min(n_components, vt.shape[0])
    components: NDArray[Any] = vt[:k]
    return mean, components


def _resolve_triplet(bands: Sequence[int] | None, n_bands: int) -> tuple[int, int, int]:
    if bands is None:
        return (0, min(1, n_bands - 1), min(2, n_bands - 1))
    indices = [int(b) for b in bands]
    if len(indices) != 3:
        raise ValueError("band-triplet mode needs exactly three band indices")
    for index in indices:
        if not 0 <= index < n_bands:
            raise ValueError(f"band index {index} out of range [0, {n_bands})")
    return (indices[0], indices[1], indices[2])


def embedding_to_rgb(
    cube: NDArray[Any],
    *,
    method: str = "pca",
    bands: Sequence[int] | None = None,
    nodata: float = DEFAULT_NODATA,
    low_pct: float = 2.0,
    high_pct: float = 98.0,
    seed: int = 0,
    max_samples: int = 100_000,
) -> NDArray[Any]:
    """Render a ``(bands, H, W)`` embedding cube to a ``(3, H, W)`` uint8 image."""
    arr = as_float(cube)
    if arr.ndim != 3:
        raise ValueError(f"expected a 3-D (bands, H, W) cube, got shape {arr.shape}")
    if method not in METHODS:
        raise ValueError(f"unknown method {method!r}; expected one of {METHODS}")
    n_bands, height, width = arr.shape
    mask = valid_mask_from_nodata(arr, nodata)
    flat_mask = mask.reshape(-1)
    out = np.zeros((3, height, width), dtype=np.uint8)
    if not np.any(flat_mask):
        return out

    if method == "pca":
        matrix = arr.reshape(n_bands, -1).T
        valid = matrix[flat_mask]
        mean, components = fit_pca(valid, 3, seed=seed, max_samples=max_samples)
        projected = (valid - mean) @ components.T
        available = projected.shape[1]
        for channel in range(3):
            if channel < available:
                values = projected[:, channel]
            else:
                values = np.zeros(projected.shape[0], dtype=projected.dtype)
            stretched = stretch_values(values, low_pct=low_pct, high_pct=high_pct)
            band = np.zeros(flat_mask.shape[0], dtype=np.uint8)
            band[flat_mask] = stretched
            out[channel] = band.reshape(height, width)
        return out

    triplet = _resolve_triplet(bands, n_bands)
    for channel, band_index in enumerate(triplet):
        values = arr[band_index].reshape(-1)[flat_mask]
        stretched = stretch_values(values, low_pct=low_pct, high_pct=high_pct)
        band = np.zeros(flat_mask.shape[0], dtype=np.uint8)
        band[flat_mask] = stretched
        out[channel] = band.reshape(height, width)
    return out
