"""Pure NumPy helpers shared by the classify / cluster algorithms.

These functions own no scikit-learn: the estimator is injected as a ``predict``
callable, so all the reshaping / masking / scattering logic is unit-testable
without sklearn installed.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any

import numpy as np
from numpy.typing import NDArray

from ._num import as_float

Predict = Callable[[NDArray[Any]], Any]


def cube_to_matrix(cube: NDArray[Any]) -> NDArray[Any]:
    """Reshape a ``(bands, H, W)`` cube to a ``(H*W, bands)`` sample matrix."""
    arr = as_float(cube)
    if arr.ndim != 3:
        raise ValueError(f"expected a 3-D (bands, H, W) cube, got shape {arr.shape}")
    bands, height, width = arr.shape
    out: NDArray[Any] = arr.reshape(bands, height * width).T
    return out


def valid_mask_from_nodata(cube: NDArray[Any], nodata: float) -> NDArray[Any]:
    """Boolean ``(H, W)`` mask of pixels that are finite and not all-nodata."""
    arr = np.asarray(cube)
    finite = np.all(np.isfinite(arr), axis=0)
    not_fill = np.any(arr != nodata, axis=0)
    out: NDArray[Any] = finite & not_fill
    return out


def encode_labels(labels: Sequence[Any]) -> tuple[NDArray[Any], list[Any]]:
    """Map arbitrary labels to contiguous int codes, preserving first-seen order.

    Returns ``(codes, classes)`` where ``classes[code]`` recovers the label.
    """
    classes: list[Any] = []
    seen: dict[Any, int] = {}
    codes = np.empty(len(labels), dtype=np.int64)
    for index, label in enumerate(labels):
        if label not in seen:
            seen[label] = len(classes)
            classes.append(label)
        codes[index] = seen[label]
    return codes, classes


def predict_in_chunks(
    matrix: NDArray[Any], predict: Predict, *, chunk: int = 100_000
) -> NDArray[Any]:
    """Apply ``predict`` to a large matrix in row chunks and concatenate results."""
    if chunk <= 0:
        raise ValueError("chunk must be positive")
    n_rows = matrix.shape[0]
    if n_rows == 0:
        empty: NDArray[Any] = np.asarray(predict(matrix[:0]))
        return empty
    parts: list[NDArray[Any]] = []
    for start in range(0, n_rows, chunk):
        block = matrix[start : start + chunk]
        parts.append(np.asarray(predict(block)))
    out: NDArray[Any] = np.concatenate(parts, axis=0)
    return out


def scatter_to_grid(
    values: NDArray[Any],
    mask: NDArray[Any],
    *,
    fill: float = 0.0,
    dtype: Any = np.float32,
) -> NDArray[Any]:
    """Scatter a 1-D ``values`` array back onto a ``(H, W)`` grid at ``mask`` pixels."""
    mask_arr = np.asarray(mask, dtype=bool)
    flat_mask = mask_arr.reshape(-1)
    n_true = int(np.count_nonzero(flat_mask))
    vals = np.asarray(values)
    if vals.shape[0] != n_true:
        raise ValueError(f"values length {vals.shape[0]} != number of True mask pixels {n_true}")
    grid = np.full(flat_mask.shape, fill, dtype=dtype)
    grid[flat_mask] = vals.astype(dtype, copy=False)
    out: NDArray[Any] = grid.reshape(mask_arr.shape)
    return out
