"""Change and trajectory metrics between embedding cubes, descriptor-aware."""

from __future__ import annotations

import itertools
from collections.abc import Sequence
from typing import Any

import numpy as np
from numpy.typing import NDArray

from ._num import as_float
from .normalize import l2_normalize

METRICS: tuple[str, ...] = ("cosine", "euclidean")


def distance_map(
    a: NDArray[Any],
    b: NDArray[Any],
    *,
    metric: str = "cosine",
    assume_unit: bool = False,
    eps: float = 1e-12,
) -> NDArray[Any]:
    """Per-pixel distance between two ``(bands, H, W)`` cubes.

    ``cosine`` returns ``1 - cos`` in ``[0, 2]``; ``euclidean`` returns the L2
    distance. For cosine on non-unit inputs the cubes are L2-normalised first.
    """
    arr_a = as_float(a)
    arr_b = as_float(b)
    if arr_a.shape != arr_b.shape:
        raise ValueError(f"cube shapes differ: {arr_a.shape} vs {arr_b.shape}")
    if metric == "cosine":
        if not assume_unit:
            arr_a = l2_normalize(arr_a, eps=eps)
            arr_b = l2_normalize(arr_b, eps=eps)
        dot = np.sum(arr_a * arr_b, axis=0)
        dist = 1.0 - dot
    elif metric == "euclidean":
        diff = arr_a - arr_b
        dist = np.sqrt(np.sum(diff * diff, axis=0))
    else:
        raise ValueError(f"unknown metric {metric!r}; expected one of {METRICS}")
    out: NDArray[Any] = np.asarray(dist).astype(arr_a.dtype, copy=False)
    return out


def mean_embedding(cubes: Sequence[NDArray[Any]]) -> NDArray[Any]:
    """Element-wise mean over a sequence of same-shaped cubes."""
    if not cubes:
        raise ValueError("need at least one cube")
    stack = np.stack([as_float(c) for c in cubes], axis=0)
    out: NDArray[Any] = np.mean(stack, axis=0)
    return out


def trajectory_magnitude(
    cubes: Sequence[NDArray[Any]],
    *,
    metric: str = "cosine",
    assume_unit: bool = False,
    eps: float = 1e-12,
) -> NDArray[Any]:
    """Sum of consecutive pairwise distances along an ordered series of cubes."""
    arrays = [as_float(c) for c in cubes]
    if len(arrays) < 2:
        raise ValueError("need at least two cubes for a trajectory")
    pairs = list(itertools.pairwise(arrays))
    (first_a, first_b) = pairs[0]
    result = distance_map(first_a, first_b, metric=metric, assume_unit=assume_unit, eps=eps)
    for prev, curr in pairs[1:]:
        result = result + distance_map(prev, curr, metric=metric, assume_unit=assume_unit, eps=eps)
    out: NDArray[Any] = result
    return out


def anomaly_from_baseline(
    cube: NDArray[Any],
    baseline: NDArray[Any],
    *,
    metric: str = "cosine",
    assume_unit: bool = False,
    eps: float = 1e-12,
) -> NDArray[Any]:
    """Distance of a cube from a baseline embedding (e.g. a temporal mean)."""
    return distance_map(cube, baseline, metric=metric, assume_unit=assume_unit, eps=eps)
