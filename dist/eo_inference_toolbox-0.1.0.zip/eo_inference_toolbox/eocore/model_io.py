"""Persist a trained estimator with enough provenance to reuse it safely.

The envelope stamps the number of embedding bands *and the backend id*, so a
model trained on (say) Clay vectors cannot be silently reused on Prithvi vectors
— the dimensions might even match, but the vector spaces do not.
"""

from __future__ import annotations

import pickle
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

ENVELOPE_VERSION = 1


def model_envelope(
    estimator: Any,
    *,
    backend_id: str,
    n_bands: int,
    kind: str,
    classes: Sequence[Any] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the metadata + estimator dict written to disk."""
    envelope: dict[str, Any] = {
        "envelope_version": ENVELOPE_VERSION,
        "backend_id": backend_id,
        "n_bands": int(n_bands),
        "kind": kind,
        "classes": list(classes) if classes is not None else None,
        "estimator": estimator,
    }
    if extra:
        envelope["extra"] = dict(extra)
    return envelope


def save_model(path: str | Path, envelope: Mapping[str, Any]) -> None:
    with open(path, "wb") as handle:
        pickle.dump(dict(envelope), handle, protocol=pickle.HIGHEST_PROTOCOL)


def load_model(path: str | Path) -> dict[str, Any]:
    with open(path, "rb") as handle:
        obj: Any = pickle.load(handle)
    if not isinstance(obj, dict):
        raise ValueError(f"{path!r} is not a valid model envelope")
    return obj


def check_compatible(envelope: Mapping[str, Any], *, backend_id: str | None, n_bands: int) -> None:
    """Raise ``ValueError`` if a saved model does not match the current cube."""
    env_bands = int(envelope.get("n_bands", -1))
    if env_bands != int(n_bands):
        raise ValueError(f"model expects {env_bands} embedding bands but the cube has {n_bands}")
    env_backend = envelope.get("backend_id")
    if env_backend and backend_id and env_backend != backend_id:
        raise ValueError(
            f"model was trained on backend {env_backend!r}, not the current {backend_id!r}"
        )
