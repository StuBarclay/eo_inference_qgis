"""Clay v1.5 backend: a multi-sensor ViT masked-autoencoder encoder.

Clay consumes a "datacube" — pixels plus metadata (acquisition time, tile
centre lat/lon, ground sample distance, and the central wavelength of each
band) — and returns patch tokens, which we reshape to a grid and upsample to the
tile's pixel resolution.

Everything torch-specific is imported lazily inside methods, so importing this
module never requires torch. The single model forward pass is isolated in
``_encode_patches`` and guarded with an actionable error, because the exact Clay
package API should be confirmed against the installed version during the smoke
test (see docs/SMOKE_TEST.md).

References
----------
- Clay model + docs: https://github.com/Clay-foundation/model
- Weights: Hugging Face ``made-with-clay/Clay`` (``clay-v1.5.ckpt``), Apache-2.0.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any

import numpy as np
from numpy.typing import NDArray

from ..descriptor import EmbeddingDescriptor
from ._pool import tokens_to_grid, upsample_nearest
from .base import TileMeta, backend_info, descriptor_from_info

if TYPE_CHECKING:
    from pathlib import Path

# Central wavelength (micrometres) per semantic band, for Sentinel-2.
WAVELENGTHS_UM: dict[str, float] = {
    "blue": 0.493,
    "green": 0.560,
    "red": 0.665,
    "nir": 0.842,
    "narrow_nir": 0.865,
    "swir1": 1.610,
    "swir2": 2.190,
}


class ClayBackend:
    """Clay v1.5 embedding backend."""

    backend_id = "clay"
    display_name = "Clay v1.5"

    def __init__(
        self,
        *,
        weights: str | Path | None = None,
        device: str | None = None,
        patch_size: int = 8,
        reflectance_scale: float = 1.0 / 10000.0,
        cache_dir: str | Path | None = None,
    ) -> None:
        self._weights = weights
        self._device_pref = device
        self._patch_size = int(patch_size)
        self._scale = float(reflectance_scale)
        self._cache_dir = cache_dir
        self._model: Any = None
        self._device: Any = None
        self._embedding_dim: int | None = None

    # -- interface ---------------------------------------------------------
    def descriptor(self) -> EmbeddingDescriptor:
        info = backend_info(self.backend_id)
        return descriptor_from_info(info, n_bands=self._embedding_dim)

    def required_bands(self) -> tuple[str, ...]:
        return backend_info(self.backend_id).default_bands

    def embed_tile(self, image: NDArray[Any], meta: TileMeta) -> NDArray[Any]:
        """Embed a ``(C_in, h, w)`` tile to a ``(D, h, w)`` cube."""
        arr = np.asarray(image, dtype=np.float32)
        if arr.ndim != 3:
            raise ValueError(f"expected (C, H, W) tile, got shape {arr.shape}")
        _, height, width = arr.shape
        self._ensure_model()
        tokens = self._encode_patches(arr, meta)  # (n_tokens, D)
        grid_h = max(1, height // self._patch_size)
        grid_w = max(1, width // self._patch_size)
        grid = tokens_to_grid(tokens, grid_h, grid_w)
        self._embedding_dim = int(grid.shape[0])
        out: NDArray[Any] = upsample_nearest(grid, height, width)
        return out

    # -- model plumbing ----------------------------------------------------
    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        try:
            import torch
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "PyTorch is required for the Clay backend; install the 'inference' dependency tier"
            ) from exc
        self._device = torch.device(
            self._device_pref
            if self._device_pref
            else ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self._model = self._load_model(self._resolve_weights())

    def _resolve_weights(self) -> Path:
        from ._weights import hf_download, resolve_local

        local = resolve_local(self._weights)
        if local is not None:
            return local
        return hf_download("made-with-clay/Clay", "clay-v1.5.ckpt", cache_dir=self._cache_dir)

    def _load_model(self, checkpoint: Path) -> Any:
        """Load the Clay Lightning module from a checkpoint.

        VERIFY during smoke test: the import path / class name below matches the
        installed ``claymodel`` version. Kept isolated so a version bump is a
        one-line change.
        """
        import torch

        try:
            from claymodel.module import ClayMAEModule  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "Could not import 'claymodel.module.ClayMAEModule'. Install Clay "
                "with: pip install git+https://github.com/Clay-foundation/model "
                "and confirm the module path in docs/SMOKE_TEST.md."
            ) from exc
        model = ClayMAEModule.load_from_checkpoint(str(checkpoint), map_location=self._device)
        model.eval()
        model.to(self._device)
        torch.set_grad_enabled(False)
        return model

    def _encode_patches(self, arr: NDArray[Any], meta: TileMeta) -> NDArray[Any]:
        """Run the Clay encoder, returning ``(n_tokens, D)`` patch tokens."""
        import torch

        datacube = self._build_datacube(arr, meta)
        model = self._model
        with torch.no_grad():
            encoder = getattr(getattr(model, "model", model), "encoder", None)
            if encoder is None:
                raise RuntimeError(
                    "Clay model exposes no '.model.encoder'; confirm the encoder "
                    "attribute for the installed version (docs/SMOKE_TEST.md)."
                )
            output = encoder(datacube)
        tokens = output[0] if isinstance(output, (tuple, list)) else output
        tensor = tokens.detach().to("cpu").float()
        if tensor.ndim == 3:  # (B, n_tokens, D) -> drop batch
            tensor = tensor[0]
        result: NDArray[Any] = tensor.numpy()
        return result

    def _build_datacube(self, arr: NDArray[Any], meta: TileMeta) -> dict[str, Any]:
        import torch

        pixels = torch.from_numpy(arr * self._scale).unsqueeze(0).to(self._device)
        waves = torch.tensor(
            [WAVELENGTHS_UM.get(b, 0.0) for b in meta.bands],
            dtype=torch.float32,
            device=self._device,
        )
        return {
            "pixels": pixels,
            "time": self._time_encoding(meta.datetime).to(self._device),
            "latlon": self._latlon_encoding(meta.lat, meta.lon).to(self._device),
            "gsd": torch.tensor(float(meta.gsd), device=self._device),
            "waves": waves,
        }

    @staticmethod
    def _time_encoding(datetime_iso: str | None) -> Any:
        import torch

        week, hour = 0.0, 0.0
        if datetime_iso:
            import datetime as _dt

            try:
                stamp = _dt.datetime.fromisoformat(datetime_iso.replace("Z", "+00:00"))
                week = stamp.isocalendar().week / 52.0
                hour = stamp.hour / 24.0
            except ValueError:
                pass
        vec = [
            math.sin(2 * math.pi * week),
            math.cos(2 * math.pi * week),
            math.sin(2 * math.pi * hour),
            math.cos(2 * math.pi * hour),
        ]
        return torch.tensor([vec], dtype=torch.float32)

    @staticmethod
    def _latlon_encoding(lat: float | None, lon: float | None) -> Any:
        import torch

        lat_r = math.radians(lat) if lat is not None else 0.0
        lon_r = math.radians(lon) if lon is not None else 0.0
        vec = [math.sin(lat_r), math.cos(lat_r), math.sin(lon_r), math.cos(lon_r)]
        return torch.tensor([vec], dtype=torch.float32)
