"""Detect optional model dependencies and offer a guided install.

Mirrors the tiered-dependency pattern used elsewhere: nothing heavy is imported
at module load; callers ask :func:`missing_packages` what is absent and either
surface a clear message or (only on explicit opt-in) call :func:`pip_install`.

Weights are never handled here — see :mod:`._weights`.
"""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from collections.abc import Sequence

from .base import BackendInfo, backend_info


def module_available(import_name: str) -> bool:
    """True if ``import_name`` can be imported without importing it."""
    try:
        return importlib.util.find_spec(import_name) is not None
    except (ImportError, ValueError):
        return False


def torch_available() -> bool:
    """True if PyTorch is importable."""
    return module_available("torch")


def missing_import_names(info: BackendInfo) -> list[str]:
    """Return the import names a backend needs that are not importable."""
    names = ("torch", *info.import_names)
    missing: list[str] = []
    for name in names:
        if not module_available(name) and name not in missing:
            missing.append(name)
    return missing


def missing_packages(backend_id: str) -> list[str]:
    """Return the pip specs to install for a backend, or ``[]`` if satisfied."""
    info = backend_info(backend_id)
    if not missing_import_names(info):
        return []
    return list(info.pip_packages)


def install_hint(backend_id: str) -> str:
    """A copy-pasteable pip command for a backend's dependencies."""
    specs = backend_info(backend_id).pip_packages
    quoted = " ".join(_quote(spec) for spec in specs)
    return f'"{sys.executable}" -m pip install {quoted}'


def _quote(spec: str) -> str:
    return f'"{spec}"' if any(ch in spec for ch in " <>=;") else spec


def pip_install(
    packages: Sequence[str], *, upgrade: bool = False, timeout: int = 3600
) -> tuple[bool, str]:
    """Install ``packages`` into the running interpreter. Opt-in only.

    Returns ``(ok, combined_output)``. The caller must have obtained explicit
    user consent — this never runs implicitly.
    """
    if not packages:
        return True, "nothing to install"
    cmd = [sys.executable, "-m", "pip", "install"]
    if upgrade:
        cmd.append("--upgrade")
    cmd.extend(packages)
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (OSError, subprocess.SubprocessError) as exc:  # pragma: no cover
        return False, f"pip invocation failed: {exc}"
    output = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode == 0, output
