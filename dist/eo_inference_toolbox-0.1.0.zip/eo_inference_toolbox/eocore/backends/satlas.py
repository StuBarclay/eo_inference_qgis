"""SatlasPretrain backend: Swin-v2 (or ResNet) + FPN, via satlaspretrain-models.

Unlike the ViT backends, Satlas emits several feature maps at different scales
(FPN outputs). This backend resamples each to the tile grid and concatenates
them into a single per-pixel embedding vector, so it presents the same
``(D, h, w)`` interface as the others.

Torch and satlaspretrain-models are imported lazily inside methods. Weights are
downloaded automatically by the package from its checkpoint id (e.g.
``Sentinel2_SwinB_SI_RGB``).

Notes on input scaling
----------------------
SatlasPretrain's Sentinel-2 models were trained on 8-bit-style imagery. The
default ``input_scale`` (1/255) assumes an 8-bit true-colour input; for raw
Sentinel-2 L2A reflectance (0-10000) pass a scale that maps your data into
roughly ``[0, 1]`` (see docs/USER_GUIDE.md).

References
----------
- https://github.com/allenai/satlaspretrain_models (ODC-BY weights).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from numpy.typing import NDArray

from ..descriptor import EmbeddingDescriptor
from ._pool import fuse_feature_maps
from .base import backend_info, descriptor_from_info

if TYPE_CHECKING:
    from pathlib import Path

    from .base import TileMeta


class SatlasBackend:
    """SatlasPretrain embedding backend (FPN feature maps pooled per pixel)."""

    backend_id = "satlas"
    display_name = "SatlasPretrain (Allen Institute / AI2)"

    def __init__(
        self,
        *,
        checkpoint: str = "Sentinel2_SwinB_SI_RGB",
        weights: str | Path | None = None,
        device: str | None = None,
        input_scale: float = 1.0 / 255.0,
        fuse: str = "concat",
    ) -> None:
        self._checkpoint = checkpoint
        self._weights = weights
        self._device_pref = device
        self._scale = float(input_scale)
        self._fuse = fuse
        self._model: Any = None
        self._device: Any = None
        self._embedding_dim: int | None = None

    # -- interface ---------------------------------------------------------
    def descriptor(self) -> EmbeddingDescriptor:
        return descriptor_from_info(backend_info(self.backend_id), n_bands=self._embedding_dim)

    def required_bands(self) -> tuple[str, ...]:
        return backend_info(self.backend_id).default_bands

    def embed_tile(self, image: NDArray[Any], meta: TileMeta) -> NDArray[Any]:
        arr = np.asarray(image, dtype=np.float32)
        if arr.ndim != 3:
            raise ValueError(f"expected (C, H, W) tile, got shape {arr.shape}")
        _, height, width = arr.shape
        self._ensure_model()
        maps = self._encode_maps(arr)  # list of (C_i, h_i, w_i)
        fused = fuse_feature_maps(maps, height, width, mode=self._fuse)
        self._embedding_dim = int(fused.shape[0])
        return fused

    # -- model plumbing ----------------------------------------------------
    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        try:
            import torch
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "PyTorch is required for the Satlas backend; install the "
                "'inference' dependency tier"
            ) from exc
        self._device = torch.device(
            self._device_pref
            if self._device_pref
            else ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self._model = self._load_model()

    def _load_model(self) -> Any:
        """Load a pretrained Satlas model with its FPN.

        VERIFY during smoke test: ``Weights().get_pretrained_model`` signature
        matches the installed satlaspretrain-models version.
        """
        import torch

        try:
            import satlaspretrain_models  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "Could not import satlaspretrain_models. Install it with: pip "
                "install satlaspretrain-models (see docs/SMOKE_TEST.md)."
            ) from exc
        manager = satlaspretrain_models.Weights()
        model = manager.get_pretrained_model(self._checkpoint, fpn=True)
        model.eval()
        model.to(self._device)
        torch.set_grad_enabled(False)
        return model

    def _encode_maps(self, arr: NDArray[Any]) -> list[NDArray[Any]]:
        """Forward pass; returns a list of ``(C_i, h_i, w_i)`` feature maps."""
        import torch

        tensor = torch.from_numpy(arr * self._scale).unsqueeze(0).to(self._device)
        with torch.no_grad():
            output = self._model(tensor)
        feature_maps = output[0] if isinstance(output, tuple) else output
        if not isinstance(feature_maps, (list, tuple)):
            feature_maps = [feature_maps]
        maps: list[NDArray[Any]] = []
        for fmap in feature_maps:
            array = fmap.detach().to("cpu").float()
            if array.ndim == 4:  # (B, C, h, w) -> drop batch
                array = array[0]
            maps.append(array.numpy())
        return maps
