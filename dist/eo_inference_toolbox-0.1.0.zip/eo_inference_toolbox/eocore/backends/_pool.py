"""Pure-NumPy helpers to turn model outputs into a per-pixel embedding tile.

ViT backends emit a coarse patch/token grid; FPN backends emit several feature
maps at different scales. Both must be resampled back to the tile's pixel grid
so every backend can present the same ``(D, h, w)`` interface. These helpers own
no torch, so they are unit-testable in the sandbox.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import numpy as np
from numpy.typing import NDArray

from .._num import as_float


def upsample_nearest(grid: NDArray[Any], out_h: int, out_w: int) -> NDArray[Any]:
    """Nearest-neighbour upsample a ``(D, gh, gw)`` grid to ``(D, out_h, out_w)``."""
    arr = as_float(grid)
    if arr.ndim != 3:
        raise ValueError(f"expected (D, gh, gw), got shape {arr.shape}")
    if out_h <= 0 or out_w <= 0:
        raise ValueError("output size must be positive")
    _, gh, gw = arr.shape
    if gh == 0 or gw == 0:
        raise ValueError("input grid has a zero spatial dimension")
    rows = (np.arange(out_h) * gh // out_h).clip(0, gh - 1)
    cols = (np.arange(out_w) * gw // out_w).clip(0, gw - 1)
    out: NDArray[Any] = arr[:, rows][:, :, cols]
    return out


def tokens_to_grid(tokens: NDArray[Any], grid_h: int, grid_w: int) -> NDArray[Any]:
    """Reshape ``(n_tokens, D)`` patch tokens to a ``(D, grid_h, grid_w)`` grid.

    If a leading class/registers token makes ``n_tokens`` one (or more) larger
    than ``grid_h * grid_w``, the extra leading tokens are dropped.
    """
    arr = as_float(tokens)
    if arr.ndim != 2:
        raise ValueError(f"expected (n_tokens, D), got shape {arr.shape}")
    n_tokens, dim = arr.shape
    expected = grid_h * grid_w
    if n_tokens < expected:
        raise ValueError(f"have {n_tokens} tokens, need {expected} for grid")
    patch = arr[n_tokens - expected :]  # drop leading non-patch tokens
    out: NDArray[Any] = patch.T.reshape(dim, grid_h, grid_w)
    return out


def fuse_feature_maps(
    maps: Sequence[NDArray[Any]], out_h: int, out_w: int, *, mode: str = "concat"
) -> NDArray[Any]:
    """Resample each ``(C_i, h_i, w_i)`` feature map to the tile grid and combine.

    ``concat`` stacks channels (dimension = sum of channels); ``sum`` requires
    equal channel counts and adds them.
    """
    if not maps:
        raise ValueError("need at least one feature map")
    resized = [upsample_nearest(as_float(m), out_h, out_w) for m in maps]
    if mode == "concat":
        out: NDArray[Any] = np.concatenate(resized, axis=0)
        return out
    if mode == "sum":
        channels = {m.shape[0] for m in resized}
        if len(channels) != 1:
            raise ValueError("'sum' mode needs equal channel counts across maps")
        stacked: NDArray[Any] = np.sum(np.stack(resized, axis=0), axis=0)
        return stacked
    raise ValueError(f"unknown fuse mode {mode!r}; expected 'concat' or 'sum'")
