"""Prithvi-EO-2.0 backend: IBM + NASA multi-temporal ViT MAE, via TerraTorch.

Prithvi expects a fixed six-band input in the pre-training order (Blue, Green,
Red, narrow-NIR, SWIR1, SWIR2), nominally at 30 m from HLS. It is multi-temporal
— input shape ``(B, C, T, H, W)`` — but a single acquisition (``T = 1``) is
fine. The backbone returns patch tokens, which we reshape to a grid and upsample
to the tile grid.

Torch and TerraTorch are imported lazily inside methods. The model build call is
isolated in ``_load_model`` and the forward pass in ``_encode_patches`` — the two
seams to confirm during the smoke test.

References
----------
- Weights: Hugging Face ``ibm-nasa-geospatial/Prithvi-EO-2.0-300M``, Apache-2.0.
- TerraTorch: https://github.com/IBM/terratorch
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from numpy.typing import NDArray

from ..descriptor import EmbeddingDescriptor
from ..stac import PRITHVI_BANDS
from ._pool import tokens_to_grid, upsample_nearest
from .base import backend_info, descriptor_from_info

if TYPE_CHECKING:
    from pathlib import Path

    from .base import TileMeta


class PrithviBackend:
    """Prithvi-EO-2.0 embedding backend (TerraTorch backbone)."""

    backend_id = "prithvi"
    display_name = "Prithvi-EO-2.0 (IBM + NASA)"

    def __init__(
        self,
        *,
        model_id: str = "prithvi_eo_v2_300",
        weights: str | Path | None = None,
        device: str | None = None,
        patch_size: int = 16,
        reflectance_scale: float = 1.0e-4,
        cache_dir: str | Path | None = None,
    ) -> None:
        self._model_id = model_id
        self._weights = weights
        self._device_pref = device
        self._patch_size = int(patch_size)
        self._scale = float(reflectance_scale)
        self._cache_dir = cache_dir
        self._model: Any = None
        self._device: Any = None
        self._embedding_dim: int | None = None

    # -- interface ---------------------------------------------------------
    def descriptor(self) -> EmbeddingDescriptor:
        return descriptor_from_info(backend_info(self.backend_id), n_bands=self._embedding_dim)

    def required_bands(self) -> tuple[str, ...]:
        return PRITHVI_BANDS

    def embed_tile(self, image: NDArray[Any], meta: TileMeta) -> NDArray[Any]:
        arr = np.asarray(image, dtype=np.float32)
        if arr.ndim != 3:
            raise ValueError(f"expected (C, H, W) tile, got shape {arr.shape}")
        n_bands, height, width = arr.shape
        if n_bands != len(PRITHVI_BANDS):
            raise ValueError(
                f"Prithvi needs exactly {len(PRITHVI_BANDS)} bands {PRITHVI_BANDS}, got {n_bands}"
            )
        self._ensure_model()
        tokens = self._encode_patches(arr)
        grid_h = max(1, height // self._patch_size)
        grid_w = max(1, width // self._patch_size)
        grid = tokens_to_grid(tokens, grid_h, grid_w)
        self._embedding_dim = int(grid.shape[0])
        out: NDArray[Any] = upsample_nearest(grid, height, width)
        return out

    # -- model plumbing ----------------------------------------------------
    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        try:
            import torch
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "PyTorch is required for the Prithvi backend; install the "
                "'inference' dependency tier"
            ) from exc
        self._device = torch.device(
            self._device_pref
            if self._device_pref
            else ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self._model = self._load_model()

    def _load_model(self) -> Any:
        """Build the Prithvi backbone via TerraTorch's registry.

        VERIFY during smoke test: registry name and ``build`` signature match the
        installed TerraTorch. An explicit local ``weights`` path is passed through
        to ``ckpt_path`` if provided.
        """
        import torch

        try:
            from terratorch.registry import (  # type: ignore[import-not-found]
                BACKBONE_REGISTRY,
            )
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "Could not import TerraTorch. Install it with: pip install "
                "terratorch, and confirm the registry path in docs/SMOKE_TEST.md."
            ) from exc
        kwargs: dict[str, Any] = {"pretrained": self._weights is None}
        if self._weights is not None:
            kwargs["ckpt_path"] = str(self._weights)
        model = BACKBONE_REGISTRY.build(self._model_id, **kwargs)
        model.eval()
        model.to(self._device)
        torch.set_grad_enabled(False)
        return model

    def _encode_patches(self, arr: NDArray[Any]) -> NDArray[Any]:
        """Forward pass; returns ``(n_tokens, D)`` tokens for the single time step."""
        import torch

        # (B=1, C, T=1, H, W)
        tensor = torch.from_numpy(arr * self._scale).unsqueeze(0).unsqueeze(2).to(self._device)
        with torch.no_grad():
            output = self._model(tensor)
        feats = output[-1] if isinstance(output, (tuple, list)) else output
        feats = feats.detach().to("cpu").float()
        if feats.ndim == 3:  # (B, n_tokens, D)
            feats = feats[0]
        result: NDArray[Any] = feats.numpy()
        return result
