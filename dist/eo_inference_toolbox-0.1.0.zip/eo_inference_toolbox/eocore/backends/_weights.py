"""Resolve and cache model weights on demand. Weights are never bundled.

Checkpoints are large and separately licensed, so they are downloaded the first
time a backend runs and cached under a user directory (override with the
``EO_INFER_WEIGHTS`` environment variable). Prithvi (TerraTorch) and Satlas
(satlaspretrain-models) fetch their own weights from Hugging Face; for those
this module only provides the cache directory. Clay's checkpoint is fetched
explicitly here.
"""

from __future__ import annotations

import os
import urllib.request
from collections.abc import Callable
from pathlib import Path

ENV_CACHE = "EO_INFER_WEIGHTS"

# Injectable stream-download hook: (url, dest_path) -> None.
DownloadFn = Callable[[str, Path], None]


def default_cache_dir() -> Path:
    """Weights cache directory (``EO_INFER_WEIGHTS`` or a per-user default)."""
    override = os.environ.get(ENV_CACHE)
    if override:
        return Path(override).expanduser()
    return Path.home() / ".cache" / "eo_inference_toolbox" / "weights"


def ensure_cache_dir(cache_dir: str | Path | None = None) -> Path:
    """Return the cache dir, creating it if needed."""
    path = Path(cache_dir).expanduser() if cache_dir else default_cache_dir()
    path.mkdir(parents=True, exist_ok=True)
    return path


def default_download(url: str, dest: Path) -> None:
    """Stream a URL to ``dest`` via stdlib urllib (documented weight hosts)."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "eo-inference-toolbox"})
    with urllib.request.urlopen(request, timeout=120) as response, open(tmp, "wb") as out:
        while True:
            chunk = response.read(1 << 20)
            if not chunk:
                break
            out.write(chunk)
    tmp.replace(dest)


def fetch_url(
    url: str,
    filename: str,
    *,
    cache_dir: str | Path | None = None,
    download: DownloadFn | None = None,
    force: bool = False,
) -> Path:
    """Download ``url`` to ``<cache>/<filename>`` unless already present."""
    cache = ensure_cache_dir(cache_dir)
    dest = cache / filename
    if dest.exists() and not force:
        return dest
    downloader = download if download is not None else default_download
    downloader(url, dest)
    return dest


def hf_download(repo_id: str, filename: str, *, cache_dir: str | Path | None = None) -> Path:
    """Fetch a file from the Hugging Face Hub (lazy import; opt-in dependency)."""
    try:
        from huggingface_hub import hf_hub_download  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover - depends on optional package
        raise RuntimeError(
            "huggingface_hub is required to fetch weights automatically; "
            "install it or pass an explicit local weights path"
        ) from exc
    cache = ensure_cache_dir(cache_dir)
    path: str = hf_hub_download(repo_id=repo_id, filename=filename, cache_dir=str(cache))
    return Path(path)


def resolve_local(weights: str | Path | None) -> Path | None:
    """Validate an explicit local weights path, if one was provided."""
    if not weights:
        return None
    path = Path(weights).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"weights not found: {path}")
    return path
