"""Backend protocol, tile metadata, and a torch-free registry of backend facts.

Nothing in this module imports torch or a model package. The concrete backend
classes live in sibling modules and are only imported by :func:`load_backend`,
which is called at run time (not import time). That keeps ``eocore.backends``
safe to import in the test sandbox and in QGIS before any weights exist.

Contract for a backend
----------------------
A backend turns an *imagery* tile into an *embedding* tile at the same pixel
grid:

    embed_tile(image[C_in, h, w], meta) -> embedding[D, h, w]

The caller (the ``embed`` algorithm) is responsible for windowing a large
raster with :mod:`eocore.tiling`, feeding tiles here, and mosaicking the
returned embedding tiles. A backend must therefore upsample its native
patch/token grid back to the tile's pixel resolution internally, so every
backend presents the same simple per-pixel interface.

Embeddings are **not** unit-normalised (``EmbeddingDescriptor.is_unit_normalized
= False`` for all three models); the ``embed`` algorithm L2-normalises before
writing, so downstream similarity/change can use the dot-product shortcut.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from ..descriptor import EmbeddingDescriptor
from ..stac import HLS_S30, PRITHVI_BANDS, RGBN_BANDS, S2_L2A

if TYPE_CHECKING:
    from numpy.typing import NDArray


@dataclass(frozen=True)
class TileMeta:
    """Per-tile context handed to a backend alongside the pixel data.

    ``bands`` are the semantic band names (see :mod:`eocore.stac`) in the same
    order as the tile's first axis. ``gsd`` is the ground sample distance in
    metres. ``lon``/``lat`` (tile centre) and ``datetime`` are optional; Clay
    uses them, the others may ignore them.
    """

    bands: tuple[str, ...]
    gsd: float
    lon: float | None = None
    lat: float | None = None
    datetime: str | None = None


@runtime_checkable
class EmbeddingBackend(Protocol):
    """The minimal interface every inference backend implements."""

    backend_id: str
    display_name: str

    def descriptor(self) -> EmbeddingDescriptor:
        """Describe the embeddings this backend produces."""
        ...

    def required_bands(self) -> tuple[str, ...]:
        """Semantic band names this backend expects, in order."""
        ...

    def embed_tile(self, image: NDArray[Any], meta: TileMeta) -> NDArray[Any]:
        """Embed one ``(C_in, h, w)`` tile to a ``(D, h, w)`` cube."""
        ...


@dataclass(frozen=True)
class BackendInfo:
    """Torch-free facts about a backend, for the GUI, docs and descriptors.

    ``embedding_dim`` and ``resolution_m`` are nominal hints for the default
    checkpoint; the live backend reports the true values via ``descriptor()``
    once a model is loaded.
    """

    backend_id: str
    display_name: str
    summary: str
    default_bands: tuple[str, ...]
    default_collection: str
    embedding_dim: int
    resolution_m: float
    is_unit_normalized: bool
    licence: str
    pip_packages: tuple[str, ...]
    weights_hint: str
    import_names: tuple[str, ...] = field(default_factory=tuple)


BACKENDS: dict[str, BackendInfo] = {
    "clay": BackendInfo(
        backend_id="clay",
        display_name="Clay v1.5",
        summary=(
            "Multi-sensor ViT masked-autoencoder (Clay Foundation). Cleanest, "
            "best-documented backend; a good default. Consumes metadata (lat/lon, "
            "time, GSD) alongside pixels."
        ),
        default_bands=RGBN_BANDS,
        default_collection=S2_L2A,
        embedding_dim=768,
        resolution_m=10.0,
        is_unit_normalized=False,
        licence="Apache-2.0 (code and weights)",
        pip_packages=("torch", "git+https://github.com/Clay-foundation/model"),
        weights_hint="Hugging Face made-with-clay/Clay -> clay-v1.5.ckpt",
        import_names=("claymodel", "clay"),
    ),
    "prithvi": BackendInfo(
        backend_id="prithvi",
        display_name="Prithvi-EO-2.0 (IBM + NASA)",
        summary=(
            "Multi-temporal ViT MAE trained on HLS. Fixed six-band input "
            "(Blue, Green, Red, narrow-NIR, SWIR1, SWIR2) at 30 m. 300M / 600M "
            "variants (plus -TL temporal-location variants). Uses TerraTorch."
        ),
        default_bands=PRITHVI_BANDS,
        default_collection=HLS_S30,
        embedding_dim=1024,
        resolution_m=30.0,
        is_unit_normalized=False,
        licence="Apache-2.0",
        pip_packages=("torch", "terratorch"),
        weights_hint="Hugging Face ibm-nasa-geospatial/Prithvi-EO-2.0-300M",
        import_names=("terratorch",),
    ),
    "satlas": BackendInfo(
        backend_id="satlas",
        display_name="SatlasPretrain (Allen Institute / AI2)",
        summary=(
            "Swin-v2 (or ResNet) backbone + FPN pretrained on Sentinel-2/1 and "
            "NAIP. Emits multi-scale feature maps that this backend pools to a "
            "single per-pixel vector. Single- and multi-image variants."
        ),
        default_bands=(RGBN_BANDS[0], RGBN_BANDS[1], RGBN_BANDS[2]),
        default_collection=S2_L2A,
        embedding_dim=1024,
        resolution_m=10.0,
        is_unit_normalized=False,
        licence="ODC-BY (weights); code Apache-2.0",
        pip_packages=("torch", "satlaspretrain-models"),
        weights_hint="checkpoint id, e.g. Sentinel2_SwinB_SI_RGB (auto-downloaded)",
        import_names=("satlaspretrain_models",),
    ),
}

BACKEND_IDS: tuple[str, ...] = tuple(BACKENDS.keys())


def backend_info(backend_id: str) -> BackendInfo:
    """Return the :class:`BackendInfo` for ``backend_id`` (raises on unknown)."""
    try:
        return BACKENDS[backend_id]
    except KeyError:
        raise KeyError(f"unknown backend {backend_id!r}; expected one of {BACKEND_IDS}") from None


def descriptor_from_info(info: BackendInfo, *, n_bands: int | None = None) -> EmbeddingDescriptor:
    """Build an :class:`EmbeddingDescriptor` from a backend's registry facts."""
    from ..descriptor import BackendCapabilities

    return EmbeddingDescriptor(
        backend_id=info.backend_id,
        n_bands=int(n_bands if n_bands is not None else info.embedding_dim),
        is_unit_normalized=info.is_unit_normalized,
        native_dtype="float32",
        resolution_m=info.resolution_m,
        temporal=info.backend_id == "prithvi",
        capabilities=BackendCapabilities(
            needs_gpu=False,
            needs_auth=info.default_collection.startswith("hls"),
            extra_deps=info.pip_packages,
        ),
    )


def load_backend(backend_id: str, **config: Any) -> EmbeddingBackend:
    """Instantiate a concrete backend by id. Imports torch lazily, at call time."""
    if backend_id == "clay":
        from .clay import ClayBackend

        return ClayBackend(**config)
    if backend_id == "prithvi":
        from .prithvi import PrithviBackend

        return PrithviBackend(**config)
    if backend_id == "satlas":
        from .satlas import SatlasBackend

        return SatlasBackend(**config)
    raise KeyError(f"unknown backend {backend_id!r}; expected one of {BACKEND_IDS}")


def resolve_bands(backend_id: str, requested: Sequence[str] | None) -> tuple[str, ...]:
    """Return ``requested`` bands if given, else the backend's default set."""
    if requested:
        return tuple(requested)
    return backend_info(backend_id).default_bands
