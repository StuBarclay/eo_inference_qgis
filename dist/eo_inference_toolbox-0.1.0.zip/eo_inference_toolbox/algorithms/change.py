"""Change and trajectory metrics across two or more aligned embedding rasters.

Three modes: ``pairwise`` (distance first vs last), ``trajectory`` (summed
consecutive distances along the ordered series) and ``anomaly`` (distance of the
last raster from the mean of the earlier ones). All rasters must share the same
pixel grid.
"""

from __future__ import annotations

from typing import Any

from numpy.typing import NDArray
from qgis.core import (
    QgsProcessing,
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingFeedback,
    QgsProcessingParameterEnum,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterRasterDestination,
    QgsProcessingUtils,
)

from ..eocore.change import (
    METRICS,
    anomaly_from_baseline,
    distance_map,
    mean_embedding,
    trajectory_magnitude,
)
from ..eocore.descriptor import DEFAULT_NODATA
from ..eocore.ml import valid_mask_from_nodata
from . import _raster
from ._common import EoInferenceAlgorithm, read_descriptor
from ._styling import apply_continuous_ramp

MODES: tuple[str, ...] = ("pairwise", "trajectory", "anomaly")


class ChangeAlgorithm(EoInferenceAlgorithm):
    """Distance / trajectory / anomaly across embedding rasters."""

    INPUT = "INPUT"
    MODE = "MODE"
    METRIC = "METRIC"
    OUTPUT = "OUTPUT"

    def __init__(self) -> None:
        super().__init__()
        self._dest_id: str = ""

    def name(self) -> str:
        return "change"

    def displayName(self) -> str:
        return "Change / trajectory"

    def shortHelpString(self) -> str:
        return (
            "Measure change across two or more aligned embedding rasters (add them in "
            "time order):\n"
            "- pairwise: distance between the first and last raster;\n"
            "- trajectory: sum of consecutive distances along the series;\n"
            "- anomaly: distance of the last raster from the mean of the earlier ones."
        )

    def initAlgorithm(self, config: dict[str, Any] | None = None) -> None:
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT,
                "Embedding rasters (in time order)",
                layerType=QgsProcessing.SourceType.TypeRaster,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(self.MODE, "Mode", options=list(MODES), defaultValue=0)
        )
        self.addParameter(
            QgsProcessingParameterEnum(self.METRIC, "Metric", options=list(METRICS), defaultValue=0)
        )
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Change"))

    def processAlgorithm(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
    ) -> dict[str, Any]:
        layers = self.parameterAsLayerList(parameters, self.INPUT, context)
        if not layers or len(layers) < 2:
            raise QgsProcessingException("Add at least two embedding rasters.")
        mode = MODES[self.parameterAsEnum(parameters, self.MODE, context)]
        metric = METRICS[self.parameterAsEnum(parameters, self.METRIC, context)]

        rasters = [_raster.read_raster(layer.source()) for layer in layers]
        first = rasters[0]
        for other in rasters[1:]:
            if not _raster.cubes_aligned(first, other):
                raise QgsProcessingException(
                    "All embedding rasters must share the same pixel grid."
                )
        cubes = [r.cube for r in rasters]
        descriptor = read_descriptor(layers[0].source(), first.cube.shape[0])
        assume_unit = descriptor.is_unit_normalized

        feedback.pushInfo(f"Computing '{mode}' change with '{metric}' metric.")
        result = self._compute(mode, cubes, metric, assume_unit)

        nodata = first.nodata if first.nodata is not None else DEFAULT_NODATA
        mask = self._combined_mask(cubes, float(nodata))
        result[~mask] = DEFAULT_NODATA

        output = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        _raster.write_geotiff(
            output,
            result,
            first.geotransform,
            first.wkt,
            nodata=DEFAULT_NODATA,
            band_names=[f"{mode}_{metric}"],
        )
        self._dest_id = output
        return {self.OUTPUT: output}

    def _compute(
        self,
        mode: str,
        cubes: list[NDArray[Any]],
        metric: str,
        assume_unit: bool,
    ) -> NDArray[Any]:
        if mode == "pairwise":
            return distance_map(cubes[0], cubes[-1], metric=metric, assume_unit=assume_unit)
        if mode == "trajectory":
            return trajectory_magnitude(cubes, metric=metric, assume_unit=assume_unit)
        baseline = mean_embedding(cubes[:-1])
        return anomaly_from_baseline(cubes[-1], baseline, metric=metric, assume_unit=assume_unit)

    def _combined_mask(self, cubes: list[NDArray[Any]], nodata: float) -> NDArray[Any]:
        mask = valid_mask_from_nodata(cubes[0], nodata)
        for cube in cubes[1:]:
            mask = mask & valid_mask_from_nodata(cube, nodata)
        return mask

    def postProcessAlgorithm(
        self, context: QgsProcessingContext, feedback: QgsProcessingFeedback
    ) -> dict[str, Any]:
        layer = QgsProcessingUtils.mapLayerFromString(self._dest_id, context)
        if layer is not None:
            apply_continuous_ramp(layer)
        return {self.OUTPUT: self._dest_id}
