"""Fetch analysis-ready satellite imagery for an AOI from a public STAC API.

Picks the least-cloudy scene in the date range for the chosen backend's default
collection (Sentinel-2 L2A on Earth Search, or HLS on the Planetary Computer),
warps its bands onto the target grid, and writes a multi-band GeoTIFF stamped
with the semantic band names and ground sample distance the ``embed`` algorithm
needs to build backend metadata.
"""

from __future__ import annotations

from typing import Any

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingFeedback,
    QgsProcessingParameterCrs,
    QgsProcessingParameterEnum,
    QgsProcessingParameterExtent,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterString,
)

from ..eocore import stac
from ..eocore.backends import backend_info
from . import _raster, _stac_fetch
from ._common import (
    BACKEND_LABELS,
    MD_BANDS,
    MD_COLLECTION,
    MD_GSD,
    EoInferenceAlgorithm,
    backend_id_from_index,
    grid_from_extent,
)


class FetchImageryAlgorithm(EoInferenceAlgorithm):
    """Download and mosaic source imagery for an AOI."""

    EXTENT = "EXTENT"
    CRS = "CRS"
    BACKEND = "BACKEND"
    START = "START"
    END = "END"
    MAX_CLOUD = "MAX_CLOUD"
    PIXEL_SIZE = "PIXEL_SIZE"
    OUTPUT = "OUTPUT"

    def name(self) -> str:
        return "fetchimagery"

    def displayName(self) -> str:
        return "Fetch imagery (STAC)"

    def shortHelpString(self) -> str:
        return (
            "Fetch the least-cloudy scene over the extent for the chosen backend's "
            "default collection and write it as a multi-band GeoTIFF.\n\n"
            "Sentinel-2 L2A is read anonymously from Earth Search. HLS is read from "
            "the Microsoft Planetary Computer and its assets are signed automatically "
            "when the 'planetary_computer' package is installed."
        )

    def initAlgorithm(self, config: dict[str, Any] | None = None) -> None:
        self.addParameter(QgsProcessingParameterExtent(self.EXTENT, "Area of interest"))
        self.addParameter(
            QgsProcessingParameterCrs(
                self.CRS, "Output CRS", defaultValue="ProjectCrs", optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.BACKEND, "Backend", options=BACKEND_LABELS, defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterString(self.START, "Start date (YYYY-MM-DD)", optional=True)
        )
        self.addParameter(
            QgsProcessingParameterString(self.END, "End date (YYYY-MM-DD)", optional=True)
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.MAX_CLOUD,
                "Maximum cloud cover (%)",
                type=QgsProcessingParameterNumber.Type.Double,
                defaultValue=20.0,
                minValue=0.0,
                maxValue=100.0,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.PIXEL_SIZE,
                "Pixel size (CRS units; 0 = backend native)",
                type=QgsProcessingParameterNumber.Type.Double,
                defaultValue=0.0,
                minValue=0.0,
            )
        )
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Imagery"))

    def processAlgorithm(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
    ) -> dict[str, Any]:
        backend_id = backend_id_from_index(self.parameterAsEnum(parameters, self.BACKEND, context))
        info = backend_info(backend_id)
        collection = info.default_collection
        bands = info.default_bands

        crs = self._resolve_crs(self.parameterAsCrs(parameters, self.CRS, context))
        pixel_size = self.parameterAsDouble(parameters, self.PIXEL_SIZE, context)
        if pixel_size <= 0:
            pixel_size = info.resolution_m
        rect = self.parameterAsExtent(parameters, self.EXTENT, context, crs)
        grid = grid_from_extent(rect, pixel_size)

        wgs = self.parameterAsExtent(
            parameters, self.EXTENT, context, QgsCoordinateReferenceSystem("EPSG:4326")
        )
        bbox = (wgs.xMinimum(), wgs.yMinimum(), wgs.xMaximum(), wgs.yMaximum())

        start = self.parameterAsString(parameters, self.START, context) or None
        end = self.parameterAsString(parameters, self.END, context) or None
        max_cloud = self.parameterAsDouble(parameters, self.MAX_CLOUD, context)

        item = self._search(collection, bbox, start, end, max_cloud, feedback)
        hrefs = stac.hrefs_for_bands(item, bands)
        signed, missing_signer = _stac_fetch.sign_hrefs(hrefs)
        if missing_signer:
            feedback.pushWarning(
                "HLS assets need signing but the 'planetary_computer' package is not "
                "installed; the read may fail. Install it with pip and retry."
            )
        if feedback.isCanceled():
            return {}

        feedback.pushInfo(f"Warping {len(signed)} band(s) onto the target grid...")
        stack = _raster.warp_bands_to_grid(signed, grid, str(crs.toWkt()))

        gsd = pixel_size if not crs.isGeographic() else info.resolution_m
        output = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        _raster.write_geotiff(
            output,
            stack,
            grid.geotransform,
            str(crs.toWkt()),
            band_names=list(bands),
            metadata={
                MD_BANDS: ",".join(bands),
                MD_GSD: f"{gsd:g}",
                MD_COLLECTION: collection,
            },
        )
        return {self.OUTPUT: output}

    def _search(
        self,
        collection: str,
        bbox: tuple[float, float, float, float],
        start: str | None,
        end: str | None,
        max_cloud: float,
        feedback: QgsProcessingFeedback,
    ) -> stac.StacItem:
        if collection == stac.S2_L2A:
            spec = stac.sentinel2_search(bbox, start=start, end=end, max_cloud=max_cloud)
        else:
            sensor = "L30" if collection == stac.HLS_L30 else "S30"
            spec = stac.hls_search(bbox, sensor=sensor, start=start, end=end, max_cloud=max_cloud)
        feedback.pushInfo(f"Searching {collection} over {bbox}...")
        try:
            items = stac.search(spec)
        except OSError as exc:
            raise QgsProcessingException(f"STAC search failed: {exc}") from exc
        item = stac.least_cloudy(items)
        if item is None:
            raise QgsProcessingException(
                "No scenes found for that extent, date range and cloud limit."
            )
        cloud = "unknown" if item.cloud_cover is None else f"{item.cloud_cover:.1f}%"
        feedback.pushInfo(f"Selected scene {item.id} (cloud cover {cloud}).")
        return item
