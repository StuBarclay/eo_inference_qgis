"""Supervised classification of an embedding raster with scikit-learn.

Either train a fresh classifier from a labelled point/polygon layer (optionally
saving the model), or load a previously trained model and apply it. Saved models
carry the backend id and band count, so a model trained on one backend's vectors
cannot be silently applied to another's. An optional confidence raster records
the winning class probability.
"""

from __future__ import annotations

import json
from typing import Any

import numpy as np
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsProcessing,
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingFeedback,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterRasterLayer,
    QgsProcessingUtils,
)

from ..eocore.descriptor import DEFAULT_NODATA
from ..eocore.ml import (
    cube_to_matrix,
    encode_labels,
    predict_in_chunks,
    scatter_to_grid,
    valid_mask_from_nodata,
)
from ..eocore.model_io import check_compatible, load_model, model_envelope, save_model
from . import _features, _raster, _sklearn
from ._common import MD_CLASSES, EoInferenceAlgorithm, as_advanced, read_descriptor
from ._styling import apply_paletted

CLASS_NODATA = -1


class ClassifyAlgorithm(EoInferenceAlgorithm):
    """Train / apply a supervised classifier over an embedding cube."""

    INPUT = "INPUT"
    TRAINING = "TRAINING"
    CLASS_FIELD = "CLASS_FIELD"
    CLASSIFIER = "CLASSIFIER"
    N_ESTIMATORS = "N_ESTIMATORS"
    SEED = "SEED"
    LOAD_MODEL = "LOAD_MODEL"
    OUTPUT = "OUTPUT"
    OUTPUT_MODEL = "OUTPUT_MODEL"
    CONFIDENCE = "CONFIDENCE"

    def __init__(self) -> None:
        super().__init__()
        self._dest_id: str = ""
        self._class_values: list[int] = []

    def name(self) -> str:
        return "classify"

    def displayName(self) -> str:
        return "Classify embedding"

    def shortHelpString(self) -> str:
        return (
            "Classify an embedding raster. Provide a labelled point/polygon layer to "
            "train a Random Forest or Gradient Boosting model (optionally saved for "
            "reuse), or load a saved model to apply it. Optionally write a confidence "
            "raster.\n\nRequires scikit-learn (install it from the toolbox dialog)."
        )

    def initAlgorithm(self, config: dict[str, Any] | None = None) -> None:
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Embedding raster"))
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.TRAINING,
                "Training samples (points or polygons)",
                types=[
                    QgsProcessing.SourceType.TypeVectorPoint,
                    QgsProcessing.SourceType.TypeVectorPolygon,
                ],
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.CLASS_FIELD,
                "Class field",
                parentLayerParameterName=self.TRAINING,
                type=QgsProcessingParameterField.DataType.Any,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.CLASSIFIER,
                "Classifier",
                options=list(_sklearn.CLASSIFIERS),
                defaultValue=0,
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterNumber(
                    self.N_ESTIMATORS,
                    "Number of trees (random forest)",
                    type=QgsProcessingParameterNumber.Type.Integer,
                    defaultValue=200,
                    minValue=1,
                )
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterNumber(
                    self.SEED,
                    "Random seed",
                    type=QgsProcessingParameterNumber.Type.Integer,
                    defaultValue=0,
                    minValue=0,
                )
            )
        )
        self.addParameter(
            QgsProcessingParameterFile(
                self.LOAD_MODEL,
                "Load a saved model (blank = train a new one)",
                optional=True,
            )
        )
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Classification"))
        model_out = QgsProcessingParameterFileDestination(
            self.OUTPUT_MODEL,
            "Save trained model",
            fileFilter="Pickled model (*.pkl)",
            optional=True,
            createByDefault=False,
        )
        self.addParameter(as_advanced(model_out))
        conf_out = QgsProcessingParameterRasterDestination(
            self.CONFIDENCE,
            "Confidence (winning probability)",
            optional=True,
            createByDefault=False,
        )
        self.addParameter(as_advanced(conf_out))

    def processAlgorithm(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
    ) -> dict[str, Any]:
        _sklearn.ensure_available()
        layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        if layer is None:
            raise QgsProcessingException("Could not load the input embedding raster.")
        path = layer.source()
        raster = _raster.read_raster(path)
        cube = raster.cube
        nodata = raster.nodata if raster.nodata is not None else DEFAULT_NODATA
        descriptor = read_descriptor(path, cube.shape[0])

        mask = valid_mask_from_nodata(cube, float(nodata))
        matrix = cube_to_matrix(cube)
        valid = matrix[mask.reshape(-1)]
        if valid.shape[0] == 0:
            raise QgsProcessingException("The embedding raster has no valid pixels.")

        estimator, classes = self._get_estimator(
            parameters, context, feedback, raster, descriptor, cube.shape[0]
        )
        if feedback.isCanceled():
            return {}

        feedback.pushInfo(f"Classifying {valid.shape[0]} pixel(s)...")
        preds = predict_in_chunks(valid, estimator.predict)
        classification = scatter_to_grid(preds, mask, fill=CLASS_NODATA, dtype=np.int32)
        self._class_values = sorted({int(v) for v in np.unique(preds)})

        output = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        _raster.write_geotiff(
            output,
            classification,
            raster.geotransform,
            raster.wkt,
            nodata=float(CLASS_NODATA),
            band_names=["class"],
            metadata={MD_CLASSES: json.dumps([str(c) for c in classes])},
        )
        self._dest_id = output
        results: dict[str, Any] = {self.OUTPUT: output}

        self._maybe_confidence(
            parameters, context, feedback, estimator, valid, mask, raster, results
        )
        return results

    # -- estimator acquisition ----------------------------------------------
    def _get_estimator(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
        raster: Any,
        descriptor: Any,
        n_bands: int,
    ) -> tuple[Any, list[Any]]:
        model_path = self.parameterAsFile(parameters, self.LOAD_MODEL, context)
        if model_path:
            envelope = load_model(model_path)
            check_compatible(envelope, backend_id=descriptor.backend_id, n_bands=n_bands)
            feedback.pushInfo(f"Loaded model trained on backend '{envelope.get('backend_id')}'.")
            return envelope["estimator"], list(envelope.get("classes") or [])
        return self._train(parameters, context, feedback, raster, descriptor, n_bands)

    def _train(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
        raster: Any,
        descriptor: Any,
        n_bands: int,
    ) -> tuple[Any, list[Any]]:
        source = self.parameterAsSource(parameters, self.TRAINING, context)
        class_field = self.parameterAsString(parameters, self.CLASS_FIELD, context)
        if source is None or not class_field:
            raise QgsProcessingException(
                "Provide training samples and a class field, or load a saved model."
            )
        dst_crs = QgsCoordinateReferenceSystem.fromWkt(raster.wkt)
        features, labels = _features.collect_training_samples(
            raster.cube,
            raster.grid_spec(),
            source,
            class_field,
            dst_crs,
            context.transformContext(),
            nodata=float(raster.nodata if raster.nodata is not None else DEFAULT_NODATA),
        )
        if features.shape[0] == 0:
            raise QgsProcessingException("No training pixels fell on valid embedding cells.")
        codes, classes = encode_labels(labels)
        algorithm = _sklearn.CLASSIFIERS[self.parameterAsEnum(parameters, self.CLASSIFIER, context)]
        estimator = _sklearn.make_classifier(
            algorithm,
            n_estimators=self.parameterAsInt(parameters, self.N_ESTIMATORS, context),
            seed=self.parameterAsInt(parameters, self.SEED, context),
        )
        feedback.pushInfo(
            f"Training {algorithm} on {features.shape[0]} samples, {len(classes)} class(es)."
        )
        estimator.fit(features, codes)
        self._save_model(parameters, context, feedback, estimator, descriptor, n_bands, classes)
        return estimator, list(classes)

    def _save_model(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
        estimator: Any,
        descriptor: Any,
        n_bands: int,
        classes: list[Any],
    ) -> None:
        model_out = self.parameterAsFileOutput(parameters, self.OUTPUT_MODEL, context)
        if not model_out:
            return
        envelope = model_envelope(
            estimator,
            backend_id=descriptor.backend_id,
            n_bands=n_bands,
            kind="classifier",
            classes=classes,
        )
        save_model(model_out, envelope)
        feedback.pushInfo(f"Saved model to {model_out}.")

    def _maybe_confidence(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
        estimator: Any,
        valid: Any,
        mask: Any,
        raster: Any,
        results: dict[str, Any],
    ) -> None:
        conf_out = self.parameterAsOutputLayer(parameters, self.CONFIDENCE, context)
        if not conf_out:
            return
        if not hasattr(estimator, "predict_proba"):
            feedback.pushWarning("Classifier has no probabilities; skipping confidence.")
            return
        proba = predict_in_chunks(valid, estimator.predict_proba)
        confidence = scatter_to_grid(proba.max(axis=1), mask, fill=DEFAULT_NODATA, dtype=np.float32)
        _raster.write_geotiff(
            conf_out,
            confidence,
            raster.geotransform,
            raster.wkt,
            nodata=DEFAULT_NODATA,
            band_names=["confidence"],
        )
        results[self.CONFIDENCE] = conf_out

    def postProcessAlgorithm(
        self, context: QgsProcessingContext, feedback: QgsProcessingFeedback
    ) -> dict[str, Any]:
        layer = QgsProcessingUtils.mapLayerFromString(self._dest_id, context)
        if layer is not None and self._class_values:
            apply_paletted(layer, self._class_values)
        return {self.OUTPUT: self._dest_id}
