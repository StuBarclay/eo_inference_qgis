"""Optional scikit-learn tier: detect, offer a guided install, build estimators.

scikit-learn is never a hard dependency and never vendored. The classify and
cluster algorithms call :func:`ensure_available` first, which raises a clear,
actionable :class:`QgsProcessingException` (with a copy-pasteable pip command)
when it is missing. The estimator factories keep the sklearn import inside the
functions, so importing this module is cheap and safe.
"""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from collections.abc import Sequence
from typing import Any

CLASSIFIERS: tuple[str, ...] = ("random_forest", "gradient_boosting")


def is_available() -> bool:
    """True if scikit-learn is importable."""
    try:
        return importlib.util.find_spec("sklearn") is not None
    except (ImportError, ValueError):
        return False


def install_hint() -> str:
    """A copy-pasteable pip command for scikit-learn."""
    return f'"{sys.executable}" -m pip install scikit-learn'


def ensure_available() -> None:
    """Raise a QGIS-friendly error if scikit-learn is absent."""
    if is_available():
        return
    from qgis.core import QgsProcessingException

    raise QgsProcessingException(
        "This algorithm needs scikit-learn, which is not installed.\n"
        f"Install it from the OSGeo4W/QGIS Python shell with:\n  {install_hint()}\n"
        "or use the 'Install scikit-learn' button in the EO Inference Toolbox dialog."
    )


def pip_install(packages: Sequence[str], *, timeout: int = 3600) -> tuple[bool, str]:
    """Install packages into the running interpreter (opt-in; needs consent)."""
    if not packages:
        return True, "nothing to install"
    cmd = [sys.executable, "-m", "pip", "install", *packages]
    try:
        proc = subprocess.run(cmd, check=False, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError) as exc:  # pragma: no cover
        return False, f"pip invocation failed: {exc}"
    return proc.returncode == 0, (proc.stdout or "") + (proc.stderr or "")


def make_classifier(algorithm: str, *, n_estimators: int = 200, seed: int = 0) -> Any:
    """Build an unfitted classifier. Imports sklearn lazily."""
    if algorithm == "random_forest":
        from sklearn.ensemble import RandomForestClassifier

        return RandomForestClassifier(
            n_estimators=int(n_estimators), random_state=int(seed), n_jobs=-1
        )
    if algorithm == "gradient_boosting":
        from sklearn.ensemble import HistGradientBoostingClassifier

        return HistGradientBoostingClassifier(random_state=int(seed))
    raise ValueError(f"unknown classifier {algorithm!r}; expected one of {CLASSIFIERS}")


def make_kmeans(n_clusters: int, *, seed: int = 0) -> Any:
    """Build an unfitted KMeans estimator. Imports sklearn lazily."""
    from sklearn.cluster import KMeans

    return KMeans(n_clusters=int(n_clusters), random_state=int(seed), n_init=10)
