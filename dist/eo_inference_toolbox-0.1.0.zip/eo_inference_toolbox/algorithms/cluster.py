"""Unsupervised K-means clustering of an embedding raster (scikit-learn).

K-means is fitted on a deterministic subsample of the valid pixels, then applied
to every valid pixel. The output is an integer cluster-id raster, styled with a
distinct colour per cluster.
"""

from __future__ import annotations

from typing import Any

import numpy as np
from qgis.core import (
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingFeedback,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterRasterLayer,
    QgsProcessingUtils,
)

from ..eocore.descriptor import DEFAULT_NODATA
from ..eocore.ml import (
    cube_to_matrix,
    predict_in_chunks,
    scatter_to_grid,
    valid_mask_from_nodata,
)
from . import _raster, _sklearn
from ._common import EoInferenceAlgorithm, as_advanced
from ._styling import apply_paletted

CLUSTER_NODATA = -1


class ClusterAlgorithm(EoInferenceAlgorithm):
    """K-means clustering over an embedding cube."""

    INPUT = "INPUT"
    N_CLUSTERS = "N_CLUSTERS"
    SEED = "SEED"
    MAX_SAMPLES = "MAX_SAMPLES"
    OUTPUT = "OUTPUT"

    def __init__(self) -> None:
        super().__init__()
        self._dest_id: str = ""
        self._cluster_values: list[int] = []

    def name(self) -> str:
        return "cluster"

    def displayName(self) -> str:
        return "Cluster embedding"

    def shortHelpString(self) -> str:
        return (
            "Group embedding pixels into K clusters with K-means (fitted on a "
            "subsample for speed). Handy for a quick unsupervised segmentation of a "
            "scene.\n\nRequires scikit-learn (install it from the toolbox dialog)."
        )

    def initAlgorithm(self, config: dict[str, Any] | None = None) -> None:
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Embedding raster"))
        self.addParameter(
            QgsProcessingParameterNumber(
                self.N_CLUSTERS,
                "Number of clusters",
                type=QgsProcessingParameterNumber.Type.Integer,
                defaultValue=8,
                minValue=2,
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterNumber(
                    self.SEED,
                    "Random seed",
                    type=QgsProcessingParameterNumber.Type.Integer,
                    defaultValue=0,
                    minValue=0,
                )
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterNumber(
                    self.MAX_SAMPLES,
                    "Maximum pixels used to fit",
                    type=QgsProcessingParameterNumber.Type.Integer,
                    defaultValue=100000,
                    minValue=1000,
                )
            )
        )
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Clusters"))

    def processAlgorithm(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
    ) -> dict[str, Any]:
        _sklearn.ensure_available()
        layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        if layer is None:
            raise QgsProcessingException("Could not load the input embedding raster.")
        raster = _raster.read_raster(layer.source())
        cube = raster.cube
        nodata = raster.nodata if raster.nodata is not None else DEFAULT_NODATA

        mask = valid_mask_from_nodata(cube, float(nodata))
        valid = cube_to_matrix(cube)[mask.reshape(-1)]
        if valid.shape[0] == 0:
            raise QgsProcessingException("The embedding raster has no valid pixels.")

        n_clusters = self.parameterAsInt(parameters, self.N_CLUSTERS, context)
        seed = self.parameterAsInt(parameters, self.SEED, context)
        max_samples = self.parameterAsInt(parameters, self.MAX_SAMPLES, context)

        sample = self._subsample(valid, max_samples, seed)
        feedback.pushInfo(
            f"Fitting {n_clusters}-means on {sample.shape[0]} of {valid.shape[0]} pixel(s)."
        )
        kmeans = _sklearn.make_kmeans(n_clusters, seed=seed)
        kmeans.fit(sample)
        if feedback.isCanceled():
            return {}

        preds = predict_in_chunks(valid, kmeans.predict)
        clusters = scatter_to_grid(preds, mask, fill=CLUSTER_NODATA, dtype=np.int32)
        self._cluster_values = sorted({int(v) for v in np.unique(preds)})

        output = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        _raster.write_geotiff(
            output,
            clusters,
            raster.geotransform,
            raster.wkt,
            nodata=float(CLUSTER_NODATA),
            band_names=["cluster"],
        )
        self._dest_id = output
        return {self.OUTPUT: output}

    def _subsample(self, valid: Any, max_samples: int, seed: int) -> Any:
        if valid.shape[0] <= max_samples:
            return valid
        rng = np.random.default_rng(seed)
        index = rng.choice(valid.shape[0], size=max_samples, replace=False)
        return valid[index]

    def postProcessAlgorithm(
        self, context: QgsProcessingContext, feedback: QgsProcessingFeedback
    ) -> dict[str, Any]:
        layer = QgsProcessingUtils.mapLayerFromString(self._dest_id, context)
        if layer is not None and self._cluster_values:
            apply_paletted(layer, self._cluster_values)
        return {self.OUTPUT: self._dest_id}
