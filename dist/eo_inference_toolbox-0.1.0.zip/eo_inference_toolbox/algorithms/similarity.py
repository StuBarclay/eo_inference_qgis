"""Per-pixel cosine similarity of an embedding raster to reference points.

The reference vector is the (normalised) mean embedding of the pixels under the
supplied point layer. The output is a single-band raster in ``[-1, 1]``, styled
with a blue-to-red ramp.
"""

from __future__ import annotations

from typing import Any

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsProcessing,
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingFeedback,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterRasterLayer,
    QgsProcessingUtils,
)

from ..eocore.descriptor import DEFAULT_NODATA
from ..eocore.ml import valid_mask_from_nodata
from ..eocore.similarity import cosine_similarity_map, reference_from_points
from . import _features, _raster
from ._common import EoInferenceAlgorithm, read_descriptor
from ._styling import apply_continuous_ramp


class SimilarityAlgorithm(EoInferenceAlgorithm):
    """Cosine-similarity map to a set of reference points."""

    INPUT = "INPUT"
    POINTS = "POINTS"
    OUTPUT = "OUTPUT"

    def __init__(self) -> None:
        super().__init__()
        self._dest_id: str = ""

    def name(self) -> str:
        return "similarity"

    def displayName(self) -> str:
        return "Similarity to reference"

    def shortHelpString(self) -> str:
        return (
            "Compute per-pixel cosine similarity of an embedding raster to the mean "
            "embedding of the pixels under a reference point layer. Output values run "
            "from -1 (opposite) to 1 (identical)."
        )

    def initAlgorithm(self, config: dict[str, Any] | None = None) -> None:
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Embedding raster"))
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.POINTS,
                "Reference points",
                types=[QgsProcessing.SourceType.TypeVectorPoint],
            )
        )
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Similarity"))

    def processAlgorithm(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
    ) -> dict[str, Any]:
        layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        if layer is None:
            raise QgsProcessingException("Could not load the input embedding raster.")
        path = layer.source()
        raster = _raster.read_raster(path)
        grid = raster.grid_spec()
        dst_crs = QgsCoordinateReferenceSystem.fromWkt(raster.wkt)

        source = self.parameterAsSource(parameters, self.POINTS, context)
        if source is None:
            raise QgsProcessingException("Could not read the reference point layer.")
        rowcols = _features.sample_reference_rowcols(
            source, grid, dst_crs, context.transformContext()
        )
        if not rowcols:
            raise QgsProcessingException("No reference points fell inside the embedding raster.")
        feedback.pushInfo(f"Averaging {len(rowcols)} reference pixel(s).")

        nodata = raster.nodata if raster.nodata is not None else DEFAULT_NODATA
        descriptor = read_descriptor(path, raster.cube.shape[0])
        reference = reference_from_points(raster.cube, rowcols, normalize=True)
        sim = cosine_similarity_map(
            raster.cube, reference, assume_unit=descriptor.is_unit_normalized
        )
        mask = valid_mask_from_nodata(raster.cube, float(nodata))
        sim[~mask] = DEFAULT_NODATA

        output = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        _raster.write_geotiff(
            output,
            sim,
            raster.geotransform,
            raster.wkt,
            nodata=DEFAULT_NODATA,
            band_names=["cosine_similarity"],
        )
        self._dest_id = output
        return {self.OUTPUT: output}

    def postProcessAlgorithm(
        self, context: QgsProcessingContext, feedback: QgsProcessingFeedback
    ) -> dict[str, Any]:
        layer = QgsProcessingUtils.mapLayerFromString(self._dest_id, context)
        if layer is not None:
            apply_continuous_ramp(layer)
        return {self.OUTPUT: self._dest_id}
