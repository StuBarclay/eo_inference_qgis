"""Run an inference backend over an imagery raster to produce an embedding cube.

The scene is cut into overlapping tiles (:mod:`eocore.tiling`), each tile is
embedded by the chosen backend, and the per-tile outputs are stitched with
overlap averaging. The mosaic is then L2-normalised (all three backends emit
non-unit vectors) so downstream similarity/change can use the dot-product
shortcut, and the descriptor is stamped into the GeoTIFF metadata.
"""

from __future__ import annotations

import dataclasses
from typing import Any

import numpy as np
from qgis.core import (
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingFeedback,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFile,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterString,
)

from ..eocore.backends import TileMeta, backend_info, load_backend
from ..eocore.descriptor import DEFAULT_NODATA
from ..eocore.normalize import l2_normalize
from ..eocore.tiling import MosaicAccumulator, iter_windows
from . import _raster
from ._common import (
    BACKEND_LABELS,
    MD_BANDS,
    EoInferenceAlgorithm,
    as_advanced,
    backend_id_from_index,
    parse_band_list,
    read_gsd,
)


class EmbedAlgorithm(EoInferenceAlgorithm):
    """Embed an imagery raster with a foundation-model backend."""

    INPUT = "INPUT"
    BACKEND = "BACKEND"
    BANDS = "BANDS"
    TILE = "TILE"
    OVERLAP = "OVERLAP"
    GSD = "GSD"
    WEIGHTS = "WEIGHTS"
    CACHE_DIR = "CACHE_DIR"
    OUTPUT = "OUTPUT"

    def name(self) -> str:
        return "embed"

    def displayName(self) -> str:
        return "Embed imagery"

    def shortHelpString(self) -> str:
        return (
            "Run a foundation-model backend (Clay, Prithvi or Satlas) over an imagery "
            "raster and write a per-pixel embedding GeoTIFF. The output is "
            "L2-normalised and tagged with the backend id so similarity, change, "
            "classify and cluster stay correct.\n\n"
            "PyTorch and the backend's model package must be installed (the "
            "'inference' dependency tier); weights download on first use."
        )

    def initAlgorithm(self, config: dict[str, Any] | None = None) -> None:
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Imagery raster"))
        self.addParameter(
            QgsProcessingParameterEnum(
                self.BACKEND, "Backend", options=BACKEND_LABELS, defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.BANDS,
                "Band order override (e.g. 'red green blue nir'; blank = auto)",
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.TILE,
                "Tile size (pixels)",
                type=QgsProcessingParameterNumber.Type.Integer,
                defaultValue=256,
                minValue=16,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.OVERLAP,
                "Tile overlap (pixels)",
                type=QgsProcessingParameterNumber.Type.Integer,
                defaultValue=32,
                minValue=0,
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterNumber(
                    self.GSD,
                    "Ground sample distance override (m; 0 = auto)",
                    type=QgsProcessingParameterNumber.Type.Double,
                    defaultValue=0.0,
                    minValue=0.0,
                )
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterFile(
                    self.WEIGHTS,
                    "Local weights checkpoint (blank = download)",
                    optional=True,
                )
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterFile(
                    self.CACHE_DIR,
                    "Weights cache folder (blank = default)",
                    behavior=QgsProcessingParameterFile.Behavior.Folder,
                    optional=True,
                )
            )
        )
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Embedding"))

    def processAlgorithm(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
    ) -> dict[str, Any]:
        layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        if layer is None:
            raise QgsProcessingException("Could not load the input imagery raster.")
        path = layer.source()
        backend_id = backend_id_from_index(self.parameterAsEnum(parameters, self.BACKEND, context))
        info = backend_info(backend_id)

        bands = self._resolve_bands(parameters, context, path, info.default_bands)
        raster = _raster.read_raster(path)
        n_in = raster.cube.shape[0]
        if n_in != len(bands):
            raise QgsProcessingException(
                f"The raster has {n_in} band(s) but the backend expects "
                f"{len(bands)} ({', '.join(bands)}). Set the band-order override or "
                "fetch imagery with this backend first."
            )
        grid = raster.grid_spec()
        lon, lat = _raster.grid_center_lonlat(grid, raster.wkt)
        gsd_param = self.parameterAsDouble(parameters, self.GSD, context)
        gsd = gsd_param if gsd_param > 0 else read_gsd(path, grid.pixel_size)

        tile = self.parameterAsInt(parameters, self.TILE, context)
        overlap = self.parameterAsInt(parameters, self.OVERLAP, context)
        if overlap >= tile:
            raise QgsProcessingException("Overlap must be smaller than the tile size.")

        backend = self._load_backend(parameters, context, backend_id)
        meta = TileMeta(bands=tuple(bands), gsd=float(gsd), lon=lon, lat=lat)
        cube = raster.cube.astype(np.float32, copy=False)
        mosaic = self._run_tiles(cube, grid, backend, meta, tile, overlap, feedback)
        if mosaic is None:
            return {}

        normalized = l2_normalize(mosaic.result(fill=0.0))
        coverage = mosaic.coverage
        normalized[:, ~coverage] = DEFAULT_NODATA

        descriptor = dataclasses.replace(
            backend.descriptor(),
            n_bands=int(normalized.shape[0]),
            is_unit_normalized=True,
        )
        output = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        _raster.write_geotiff(
            output,
            normalized,
            grid.geotransform,
            raster.wkt,
            nodata=DEFAULT_NODATA,
            metadata=self._stamp(descriptor),
        )
        feedback.pushInfo(
            f"Wrote a {normalized.shape[0]}-band embedding from backend '{backend_id}'."
        )
        return {self.OUTPUT: output}

    # -- helpers -------------------------------------------------------------
    def _resolve_bands(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        path: str,
        default_bands: tuple[str, ...],
    ) -> tuple[str, ...]:
        override = parse_band_list(self.parameterAsString(parameters, self.BANDS, context))
        if override is not None:
            return override
        stamped = _raster.read_metadata_item(path, MD_BANDS)
        from_meta = parse_band_list(stamped)
        if from_meta is not None:
            return from_meta
        return tuple(default_bands)

    def _load_backend(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        backend_id: str,
    ) -> Any:
        weights = self.parameterAsFile(parameters, self.WEIGHTS, context) or None
        cache_dir = self.parameterAsFile(parameters, self.CACHE_DIR, context) or None
        config: dict[str, Any] = {}
        if weights:
            config["weights"] = weights
        if cache_dir:
            config["cache_dir"] = cache_dir
        try:
            return load_backend(backend_id, **config)
        except (ImportError, RuntimeError) as exc:
            raise QgsProcessingException(str(exc)) from exc

    def _run_tiles(
        self,
        cube: Any,
        grid: Any,
        backend: Any,
        meta: TileMeta,
        tile: int,
        overlap: int,
        feedback: QgsProcessingFeedback,
    ) -> MosaicAccumulator | None:
        windows = list(iter_windows(grid.width, grid.height, tile, overlap))
        total = len(windows)
        accumulator: MosaicAccumulator | None = None
        for index, window in enumerate(windows):
            if feedback.isCanceled():
                return None
            chip = cube[
                :,
                window.row_off : window.row_end,
                window.col_off : window.col_end,
            ]
            try:
                embedded = backend.embed_tile(np.ascontiguousarray(chip), meta)
            except (ImportError, RuntimeError) as exc:
                raise QgsProcessingException(str(exc)) from exc
            if accumulator is None:
                accumulator = MosaicAccumulator(int(embedded.shape[0]), grid.height, grid.width)
            accumulator.add(window, np.asarray(embedded, dtype=np.float32))
            feedback.setProgress(int(100 * (index + 1) / max(total, 1)))
        if accumulator is None:
            raise QgsProcessingException("No tiles were produced from the raster.")
        return accumulator
