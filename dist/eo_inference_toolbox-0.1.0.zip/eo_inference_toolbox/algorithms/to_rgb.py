"""Render a high-dimensional embedding raster to a 3-band RGB preview GeoTIFF.

Two methods: a 3-component PCA fitted on the valid pixels (default), or three
chosen embedding bands. Each channel is percentile-stretched to 8-bit; invalid
pixels are written as black.
"""

from __future__ import annotations

from typing import Any

from qgis.core import (
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingFeedback,
    QgsProcessingParameterEnum,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterString,
)

from ..eocore.descriptor import DEFAULT_NODATA
from ..eocore.rgb import METHODS, embedding_to_rgb
from . import _raster
from ._common import EoInferenceAlgorithm, as_advanced, parse_band_list


class ToRgbAlgorithm(EoInferenceAlgorithm):
    """Make an RGB preview of an embedding cube."""

    INPUT = "INPUT"
    METHOD = "METHOD"
    BANDS = "BANDS"
    LOW_PCT = "LOW_PCT"
    HIGH_PCT = "HIGH_PCT"
    SEED = "SEED"
    OUTPUT = "OUTPUT"

    def name(self) -> str:
        return "torgb"

    def displayName(self) -> str:
        return "Embedding to RGB"

    def shortHelpString(self) -> str:
        return (
            "Render an embedding raster to a 3-band RGB preview, either by a "
            "3-component PCA of the valid pixels or by selecting three bands. Useful "
            "for a quick visual sanity check of an embedding."
        )

    def initAlgorithm(self, config: dict[str, Any] | None = None) -> None:
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Embedding raster"))
        self.addParameter(
            QgsProcessingParameterEnum(self.METHOD, "Method", options=list(METHODS), defaultValue=0)
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.BANDS,
                "Band triplet for the 'bands' method (e.g. '0 1 2')",
                optional=True,
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterNumber(
                    self.LOW_PCT,
                    "Low stretch percentile",
                    type=QgsProcessingParameterNumber.Type.Double,
                    defaultValue=2.0,
                    minValue=0.0,
                    maxValue=50.0,
                )
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterNumber(
                    self.HIGH_PCT,
                    "High stretch percentile",
                    type=QgsProcessingParameterNumber.Type.Double,
                    defaultValue=98.0,
                    minValue=50.0,
                    maxValue=100.0,
                )
            )
        )
        self.addParameter(
            as_advanced(
                QgsProcessingParameterNumber(
                    self.SEED,
                    "PCA sampling seed",
                    type=QgsProcessingParameterNumber.Type.Integer,
                    defaultValue=0,
                    minValue=0,
                )
            )
        )
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "RGB preview"))

    def processAlgorithm(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        feedback: QgsProcessingFeedback,
    ) -> dict[str, Any]:
        layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        if layer is None:
            raise QgsProcessingException("Could not load the input embedding raster.")
        raster = _raster.read_raster(layer.source())
        nodata = raster.nodata if raster.nodata is not None else DEFAULT_NODATA
        method = METHODS[self.parameterAsEnum(parameters, self.METHOD, context)]
        triplet = self._resolve_triplet(parameters, context, method)
        low = self.parameterAsDouble(parameters, self.LOW_PCT, context)
        high = self.parameterAsDouble(parameters, self.HIGH_PCT, context)
        seed = self.parameterAsInt(parameters, self.SEED, context)

        feedback.pushInfo(f"Rendering RGB via '{method}'...")
        rgb = embedding_to_rgb(
            raster.cube,
            method=method,
            bands=triplet,
            nodata=float(nodata),
            low_pct=low,
            high_pct=high,
            seed=seed,
        )
        output = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        _raster.write_geotiff(
            output,
            rgb,
            raster.geotransform,
            raster.wkt,
            band_names=["red", "green", "blue"],
            color_interp_rgb=True,
        )
        return {self.OUTPUT: output}

    def _resolve_triplet(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        method: str,
    ) -> tuple[int, int, int] | None:
        parsed = parse_band_list(self.parameterAsString(parameters, self.BANDS, context))
        if parsed is None:
            if method == "bands":
                raise QgsProcessingException(
                    "The 'bands' method needs a triplet of band indices, e.g. '0 1 2'."
                )
            return None
        try:
            indices = [int(token) for token in parsed]
        except ValueError as exc:
            raise QgsProcessingException("Band triplet must be integers.") from exc
        if len(indices) != 3:
            raise QgsProcessingException("Band triplet needs exactly three indices.")
        return (indices[0], indices[1], indices[2])
